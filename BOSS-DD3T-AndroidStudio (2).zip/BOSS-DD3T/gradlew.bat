@rem
@rem Copyright 2015 the original author or authors.
@rem Licensed under the Apache License, Version 2.0
@rem

@if "%DEBUG%"=="" @echo off
@rem ##########################################################################
@rem  Gradle startup script for Windows
@rem ##########################################################################

if "%OS%"=="Windows_NT" setlocal

set DIRNAME=%~dp0
if "%DIRNAME%"=="" set DIRNAME=.
set APP_BASE_NAME=%~n0
set APP_HOME=%DIRNAME%

for %%i in ("%APP_HOME%") do set APP_HOME=%%~fi

set DEFAULT_JVM_OPTS="-Xmx64m" "-Xms64m"

if defined JAVA_HOME goto findJavaFromJavaHome

set JAVA_EXE=java.exe
set JAVAC_EXE=javac.exe
set JAR_EXE=jar.exe
%JAVA_EXE% -version >NUL 2>&1
if %ERRORLEVEL% equ 0 goto execute

echo.
echo ERROR: JAVA_HOME is not set and no 'java' command could be found in your PATH.
goto fail

:findJavaFromJavaHome
set JAVA_HOME=%JAVA_HOME:"=%
set JAVA_EXE=%JAVA_HOME%/bin/java.exe
set JAVAC_EXE=%JAVA_HOME%/bin/javac.exe
set JAR_EXE=%JAVA_HOME%/bin/jar.exe

if exist "%JAVA_EXE%" goto execute

echo.
echo ERROR: JAVA_HOME is set to an invalid directory: %JAVA_HOME%
goto fail

:execute
set CLASSPATH=%APP_HOME%\gradle\wrapper\gradle-wrapper.jar

"%JAR_EXE%" tf "%CLASSPATH%" 2>NUL | findstr /C:"org/gradle/wrapper/GradleWrapperMain.class" >NUL
if %ERRORLEVEL% neq 0 (
    set TMP_WRAP=%TEMP%\dd3t-wrap-%RANDOM%
    mkdir "%TMP_WRAP%\org\gradle\wrapper"
    powershell -NoProfile -Command "$c = Get-Content -Raw '%APP_HOME%\gradlew'; $m = [regex]::Match($c, '(?s)cat << ''EOF'' > \"\$TMP_WRAPPER_SRC/org/gradle/wrapper/GradleWrapperMain\.java\"\r?\n(.*?)\r?\nEOF'); Set-Content -Path '%TMP_WRAP%\org\gradle\wrapper\GradleWrapperMain.java' -Value $m.Groups[1].Value -Encoding UTF8"
    "%JAVAC_EXE%" -source 17 -target 17 -d "%TMP_WRAP%" "%TMP_WRAP%\org\gradle\wrapper\GradleWrapperMain.java"
    "%JAR_EXE%" cfe "%CLASSPATH%" org.gradle.wrapper.GradleWrapperMain -C "%TMP_WRAP%" org
    rmdir /S /Q "%TMP_WRAP%"
)

"%JAVA_EXE%" %DEFAULT_JVM_OPTS% %JAVA_OPTS% %GRADLE_OPTS% "-Dorg.gradle.appname=%APP_BASE_NAME%" -classpath "%CLASSPATH%" org.gradle.wrapper.GradleWrapperMain %*

:end
if %ERRORLEVEL% equ 0 goto mainEnd

:fail
exit /b 1

:mainEnd
if "%OS%"=="Windows_NT" endlocal

:omega
