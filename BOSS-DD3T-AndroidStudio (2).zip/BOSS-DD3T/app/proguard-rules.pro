# Preserve JavascriptInterface methods used by assets/index.html
-keepclassmembers class com.numair.bossdd3t.MainActivity$AndroidBridge {
    @android.webkit.JavascriptInterface <methods>;
}
