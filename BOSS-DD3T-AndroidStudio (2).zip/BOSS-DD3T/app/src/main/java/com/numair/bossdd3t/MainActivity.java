package com.numair.bossdd3t;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ClipData;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.webkit.ConsoleMessage;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.webkit.WebViewAssetLoader;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * MainActivity hosting the BOSS DD-3T Digital Delay Simulator inside a hardware-accelerated,
 * low-latency Android WebView served locally via WebViewAssetLoader (https://appassets.androidplatform.net).
 */
public class MainActivity extends AppCompatActivity {

    private static final String TAG = "BossDD3T";
    private static final String APP_ASSET_HOST = "appassets.androidplatform.net";
    private static final String APP_START_URL = "https://appassets.androidplatform.net/assets/index.html";

    private WebView webView;
    private PermissionRequest pendingWebPermissionRequest;
    private ValueCallback<Uri[]> fileUploadCallback;
    private long lastBackPressMillis = 0L;

    private AudioManager audioManager;
    private AudioFocusRequest audioFocusRequest;

    // Runtime RECORD_AUDIO permission launcher synchronized with WebChromeClient.onPermissionRequest
    private final ActivityResultLauncher<String> recordAudioPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
                PermissionRequest request = pendingWebPermissionRequest;
                pendingWebPermissionRequest = null;

                if (request == null) {
                    return;
                }

                if (isGranted) {
                    try {
                        request.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
                    } catch (Exception e) {
                        Log.e(TAG, "Failed to grant WebView audio capture permission", e);
                    }
                } else {
                    try {
                        request.deny();
                    } catch (Exception e) {
                        Log.e(TAG, "Failed to deny WebView audio capture permission", e);
                    }
                    Toast.makeText(
                            this,
                            "Microphone permission is required for Live Mic and Voice Recording.",
                            Toast.LENGTH_LONG
                    ).show();
                }
            });

    // Audio file chooser launcher for <input type="file"> (Import Audio)
    private final ActivityResultLauncher<Intent> audioFileChooserLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
                ValueCallback<Uri[]> callback = fileUploadCallback;
                fileUploadCallback = null;

                if (callback == null) {
                    return;
                }

                Uri[] results = null;
                if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                    Intent data = result.getData();
                    if (data.getClipData() != null) {
                        ClipData clipData = data.getClipData();
                        int count = clipData.getItemCount();
                        results = new Uri[count];
                        for (int i = 0; i < count; i++) {
                            results[i] = clipData.getItemAt(i).getUri();
                        }
                    } else if (data.getData() != null) {
                        results = new Uri[]{data.getData()};
                    }
                }

                try {
                    callback.onReceiveValue(results);
                } catch (Exception e) {
                    Log.e(TAG, "Error delivering selected audio URI to WebView", e);
                }
            });

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Route hardware volume buttons to media/effect output & keep screen awake during sessions
        setVolumeControlStream(AudioManager.STREAM_MUSIC);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().getDecorView().setBackgroundColor(Color.parseColor("#0B0D11"));

        setContentView(R.layout.activity_main);

        requestMediaAudioFocus();

        webView = findViewById(R.id.dd3t_webview);
        configureWebView(webView);
        setupBackNavigation();

        if (savedInstanceState == null) {
            webView.loadUrl(APP_START_URL);
        } else {
            webView.restoreState(savedInstanceState);
        }
    }

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    private void configureWebView(@NonNull WebView view) {
        view.setBackgroundColor(Color.parseColor("#0B0D11"));
        view.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        view.setOverScrollMode(View.OVER_SCROLL_NEVER);
        view.setHapticFeedbackEnabled(true);

        // Prevent accidental long-press context reload/copy overlays on knobs & footswitch
        view.setOnLongClickListener(v -> true);
        view.setLongClickable(false);

        WebSettings settings = view.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        // Serve local assets under a secure HTTPS origin (https://appassets.androidplatform.net/assets/index.html)
        // so Web Audio API, getUserMedia(), AudioWorklet, MediaRecorder, and localStorage operate in a full Secure Context.
        final WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
                .setDomain(APP_ASSET_HOST)
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        view.setWebViewClient(new WebViewClient() {
            @Nullable
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView webView, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView webView, WebResourceRequest request) {
                Uri uri = request.getUrl();
                if (uri != null && APP_ASSET_HOST.equalsIgnoreCase(uri.getHost())) {
                    return false;
                }
                if (uri != null) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, uri));
                    } catch (Exception ignored) {
                    }
                }
                return true;
            }
        });

        view.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> {
                    if (request == null) {
                        return;
                    }

                    Uri origin = request.getOrigin();
                    if (origin == null || !APP_ASSET_HOST.equalsIgnoreCase(origin.getHost())) {
                        request.deny();
                        return;
                    }

                    String[] requestedResources = request.getResources();
                    List<String> validAudioResources = new ArrayList<>();
                    if (requestedResources != null) {
                        for (String res : requestedResources) {
                            if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(res)) {
                                validAudioResources.add(res);
                            }
                        }
                    }

                    if (validAudioResources.isEmpty()) {
                        request.deny();
                        return;
                    }

                    if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.RECORD_AUDIO)
                            == PackageManager.PERMISSION_GRANTED) {
                        request.grant(validAudioResources.toArray(new String[0]));
                    } else {
                        if (pendingWebPermissionRequest != null) {
                            try {
                                pendingWebPermissionRequest.deny();
                            } catch (Exception ignored) {
                            }
                        }
                        pendingWebPermissionRequest = request;
                        recordAudioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO);
                    }
                });
            }

            @Override
            public void onPermissionRequestCanceled(PermissionRequest request) {
                runOnUiThread(() -> {
                    if (pendingWebPermissionRequest == request) {
                        pendingWebPermissionRequest = null;
                    }
                });
            }

            @Override
            public boolean onShowFileChooser(
                    WebView webView,
                    ValueCallback<Uri[]> filePathCallback,
                    FileChooserParams fileChooserParams
            ) {
                if (fileUploadCallback != null) {
                    try {
                        fileUploadCallback.onReceiveValue(null);
                    } catch (Exception ignored) {
                    }
                }
                fileUploadCallback = filePathCallback;

                try {
                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("audio/*");
                    intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                            "audio/*",
                            "audio/mpeg",
                            "audio/wav",
                            "audio/x-wav",
                            "audio/ogg",
                            "audio/mp4",
                            "audio/aac",
                            "audio/flac"
                    });
                    audioFileChooserLauncher.launch(Intent.createChooser(intent, "Select Audio File"));
                    return true;
                } catch (Exception e) {
                    Log.e(TAG, "Unable to launch audio file chooser", e);
                    if (fileUploadCallback != null) {
                        fileUploadCallback.onReceiveValue(null);
                        fileUploadCallback = null;
                    }
                    Toast.makeText(MainActivity.this, "No audio file picker available on this device.", Toast.LENGTH_SHORT).show();
                    return false;
                }
            }

            @Override
            public boolean onConsoleMessage(ConsoleMessage consoleMessage) {
                if (consoleMessage != null && consoleMessage.messageLevel() == ConsoleMessage.MessageLevel.ERROR) {
                    Log.e(TAG, "WebView JS Error: " + consoleMessage.message() + " (" + consoleMessage.sourceId() + ":" + consoleMessage.lineNumber() + ")");
                }
                return super.onConsoleMessage(consoleMessage);
            }
        });

        view.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
    }

    private void setupBackNavigation() {
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (webView == null) {
                    finish();
                    return;
                }

                webView.evaluateJavascript(
                        "(function(){ return typeof window.__dd3tHandleAndroidBack === 'function' ? window.__dd3tHandleAndroidBack() : false; })()",
                        value -> {
                            if ("true".equals(value)) {
                                return;
                            }
                            if (webView.canGoBack()) {
                                webView.goBack();
                                return;
                            }
                            long now = System.currentTimeMillis();
                            if (now - lastBackPressMillis < 2000L) {
                                finish();
                            } else {
                                lastBackPressMillis = now;
                                Toast.makeText(
                                        MainActivity.this,
                                        "Press back again to exit BOSS DD-3T",
                                        Toast.LENGTH_SHORT
                                ).show();
                            }
                        }
                );
            }
        });
    }

    private void requestMediaAudioFocus() {
        audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        if (audioManager == null) {
            return;
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            AudioAttributes attrs = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build();
            audioFocusRequest = new AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
                    .setAudioAttributes(attrs)
                    .setAcceptsDelayedFocusGain(true)
                    .setOnAudioFocusChangeListener(focusChange -> {
                        // Keep Web Audio DSP graph intact across transient focus changes
                    })
                    .build();
            audioManager.requestAudioFocus(audioFocusRequest);
        } else {
            audioManager.requestAudioFocus(null, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
        }
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        if (webView != null) {
            webView.saveState(outState);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) {
            webView.onResume();
        }
    }

    @Override
    protected void onDestroy() {
        if (audioManager != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && audioFocusRequest != null) {
            audioManager.abandonAudioFocusRequest(audioFocusRequest);
        }
        if (webView != null) {
            webView.stopLoading();
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }

    /**
     * Native JavaScript bridge allowing the WebView's Export WAV button to save processed
     * audio recordings directly into Android's public Downloads/BOSS-DD3T folder.
     */
    public class AndroidBridge {

        @JavascriptInterface
        public String saveAudioFile(String base64Data, String fileName, String mimeType) {
            try {
                if (base64Data == null || base64Data.isEmpty()) {
                    return "ERROR:Empty audio data";
                }

                String cleanBase64 = base64Data;
                int commaIdx = cleanBase64.indexOf(',');
                if (commaIdx >= 0) {
                    cleanBase64 = cleanBase64.substring(commaIdx + 1);
                }

                byte[] audioBytes = Base64.decode(cleanBase64, Base64.DEFAULT);
                if (audioBytes == null || audioBytes.length == 0) {
                    return "ERROR:Decoded audio is empty";
                }

                String safeName = (fileName != null && !fileName.trim().isEmpty())
                        ? fileName.replaceAll("[^a-zA-Z0-9._-]", "_")
                        : ("BOSS-DD3T-" + System.currentTimeMillis() + ".wav");
                String safeMime = (mimeType != null && !mimeType.trim().isEmpty()) ? mimeType : "audio/wav";

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    ContentResolver resolver = getContentResolver();
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Downloads.DISPLAY_NAME, safeName);
                    values.put(MediaStore.Downloads.MIME_TYPE, safeMime);
                    values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/BOSS-DD3T");
                    values.put(MediaStore.Downloads.IS_PENDING, 1);

                    Uri itemUri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                    if (itemUri == null) {
                        return "ERROR:Unable to create file in Downloads";
                    }

                    try (OutputStream out = resolver.openOutputStream(itemUri)) {
                        if (out == null) {
                            return "ERROR:Unable to open output stream";
                        }
                        out.write(audioBytes);
                        out.flush();
                    }

                    values.clear();
                    values.put(MediaStore.Downloads.IS_PENDING, 0);
                    resolver.update(itemUri, values, null, null);
                } else {
                    File downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                    File appDir = new File(downloadsDir, "BOSS-DD3T");
                    if (!appDir.exists() && !appDir.mkdirs()) {
                        return "ERROR:Unable to create Downloads/BOSS-DD3T folder";
                    }
                    File outFile = new File(appDir, safeName);
                    try (FileOutputStream fos = new FileOutputStream(outFile)) {
                        fos.write(audioBytes);
                        fos.flush();
                    }
                    MediaScannerConnection.scanFile(
                            MainActivity.this,
                            new String[]{outFile.getAbsolutePath()},
                            new String[]{safeMime},
                            null
                    );
                }

                final String savedDisplay = "Downloads/BOSS-DD3T/" + safeName;
                runOnUiThread(() -> Toast.makeText(
                        MainActivity.this,
                        "Saved to " + savedDisplay,
                        Toast.LENGTH_LONG
                ).show());

                return "OK:" + savedDisplay;
            } catch (Exception e) {
                Log.e(TAG, "Failed to export audio file", e);
                return "ERROR:" + (e.getMessage() != null ? e.getMessage() : "Export failed");
            }
        }
    }
}
